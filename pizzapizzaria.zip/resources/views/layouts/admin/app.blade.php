
@include('layouts.admin.header')
@include('layouts.admin.sidebar')
@include('layouts.admin.topnav')
   @yield('content')
@include('layouts.admin.footer')

     