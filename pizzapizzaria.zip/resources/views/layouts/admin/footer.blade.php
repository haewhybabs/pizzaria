<!--           <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer> -->

    <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="{{ asset('adminAssets/js/jquery.min.js')}}"></script>
    <script src="{{ asset('adminAssets/js/gistfile1.js')}}"></script>

       <!-- Bootstrap -->
    <script src="{{ asset('adminAssets/js/bootstrap.min.js')}}"></script>
    
    <!-- FastClick -->
    <script src="{{ asset('adminAssets/js/fastclick.js')}}"></script>
    
    <!-- NProgress -->
    <script src="{{ asset('adminAssets/js/nprogress.js')}}"></script>
      <script type="text/javascript" src="{{ asset('adminAssets/js/dropify.min.js')}}"></script>
    
    <!-- Custom Theme Scripts -->

@yield('js') 
    <script src="{{ asset('adminAssets/js/custom.min.js')}}"></script>
</script>



      
      
  
  </body>
</html>
