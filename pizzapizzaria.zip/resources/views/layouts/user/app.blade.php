@include('layouts.user.header')
@include('layouts.user.topnav')
   @yield('content')
@include('layouts.user.footer')