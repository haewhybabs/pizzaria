<div>
	You got message from {{ $fr }}
</div>
<div>
	About : {{ $sub }}
</div>
<div>
	Comments : {{ $comments }}
</div>
