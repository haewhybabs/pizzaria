<div>
	We got your message regarding <strong>{{ $usersub }}</strong> in which you're talking about <p>{{ $userMessage }}</p> so,	
</div>
<div>
	{{ $msg }}
</div>